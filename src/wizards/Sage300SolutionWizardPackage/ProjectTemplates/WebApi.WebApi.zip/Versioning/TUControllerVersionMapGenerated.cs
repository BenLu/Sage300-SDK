// Copyright (c) 1994-2019 Sage Software, Inc.  All rights reserved.

using Microsoft.Web.Http;

namespace Sage.CA.SBS.ERP.Sage300.TU.WebApi.Controllers
{

}