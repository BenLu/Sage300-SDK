﻿/* Copyright (c) 2021 Sage Software, Inc.  All rights reserved. */

"use strict";

$(function () {
    $("#hdnFunctionalCurrency").val(DeclarativeReportViewModel.FunctionalCurrency);
});
